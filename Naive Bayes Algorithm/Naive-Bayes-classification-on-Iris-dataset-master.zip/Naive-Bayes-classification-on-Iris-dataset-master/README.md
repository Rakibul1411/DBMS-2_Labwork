# Naive-Bayes-classification-on-Iris-dataset
Using Naive Bayes classification approach to identify the different species of Iris flowers.
